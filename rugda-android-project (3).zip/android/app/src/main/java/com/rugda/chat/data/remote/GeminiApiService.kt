package com.rugda.chat.data.remote

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiApiService(apiKey: String) {

    private val flashModel = GenerativeModel(
        modelName = "gemini-1.5-flash",
        apiKey = apiKey
    )

    private val proModel = GenerativeModel(
        modelName = "gemini-1.5-pro",
        apiKey = apiKey
    )

    suspend fun generateAiReply(prompt: String, useProModel: Boolean = false): String = withContext(Dispatchers.IO) {
        try {
            val model = if (useProModel) proModel else flashModel
            val response = model.generateContent(
                content {
                    text("You are RUGDA AI, an intelligent, helpful assistant inside the RUGDA messaging app. Keep replies clear, engaging, and friendly.\n\nUser Question: $prompt")
                }
            )
            response.text ?: "I am ready to assist you on RUGDA!"
        } catch (e: Exception) {
            "RUGDA AI Service Note: " + (e.localizedMessage ?: "Unable to process request right now.")
        }
    }

    suspend fun translateText(text: String, targetLanguage: String): String = withContext(Dispatchers.IO) {
        try {
            val response = flashModel.generateContent(
                content {
                    text("Translate the following message precisely into $targetLanguage. Output ONLY the translated string without commentary or quotation marks:\n\n$text")
                }
            )
            response.text?.trim() ?: text
        } catch (e: Exception) {
            text
        }
    }

    suspend fun summarizeChatHistory(messages: List<String>): String = withContext(Dispatchers.IO) {
        try {
            val combined = messages.joinToString("\n")
            val response = flashModel.generateContent(
                content {
                    text("Provide a 3-bullet summary of key points and actionable items from this chat transcript:\n\n$combined")
                }
            )
            response.text ?: "No key summary items detected."
        } catch (e: Exception) {
            "Unable to summarize chat history at this time."
        }
    }
}
