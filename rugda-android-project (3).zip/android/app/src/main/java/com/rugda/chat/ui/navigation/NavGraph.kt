package com.rugda.chat.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.rugda.chat.ui.screens.*

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.ChatList.route
    ) {
        composable(Screen.Auth.route) {
            AuthScreen(onLoginSuccess = {
                navController.navigate(Screen.ChatList.route) {
                    popUpTo(Screen.Auth.route) { inclusive = true }
                }
            })
        }

        composable(Screen.ChatList.route) {
            ChatListScreen(
                onOpenChat = { id, name ->
                    navController.navigate(Screen.ChatDetail.createRoute(id, name))
                },
                onOpenAiAssistant = {
                    navController.navigate(Screen.AiAssistant.route)
                },
                onOpenSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(
            route = Screen.ChatDetail.route,
            arguments = listOf(
                navArgument("chatId") { type = NavType.StringType },
                navArgument("chatName") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: "c1"
            val chatName = backStackEntry.arguments?.getString("chatName") ?: "Chat"
            ChatDetailScreen(
                chatId = chatId,
                chatName = chatName,
                onBack = { navController.popBackStack() },
                onStartCall = { isVideo ->
                    navController.navigate(Screen.Call.route)
                }
            )
        }

        composable(Screen.AiAssistant.route) {
            AiAssistantScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Call.route) {
            CallScreen(onEndCall = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
