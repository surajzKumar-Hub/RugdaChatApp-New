package com.rugda.chat.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.rugda.chat.data.model.Chat
import com.rugda.chat.data.model.Message
import com.rugda.chat.data.model.MessageStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.InputStream
import java.util.UUID

class ChatRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {
    fun getChatsForUser(userId: String): Flow<List<Chat>> = callbackFlow {
        val listener = firestore.collection("chats")
            .whereArrayContains("participants", userId)
            .orderBy("lastMessageTime", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val chats = snapshot?.documents?.mapNotNull { it.toObject(Chat::class.java) } ?: emptyList()
                trySend(chats)
            }

        awaitClose { listener.remove() }
    }

    fun getMessagesForChat(chatId: String): Flow<List<Message>> = callbackFlow {
        val listener = firestore.collection("chats")
            .document(chatId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val messages = snapshot?.documents?.mapNotNull { it.toObject(Message::class.java) } ?: emptyList()
                trySend(messages)
            }

        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(chatId: String, message: Message) {
        val docRef = firestore.collection("chats").document(chatId).collection("messages").document()
        val finalMessage = message.copy(id = docRef.id, chatId = chatId, status = MessageStatus.SENT)
        docRef.set(finalMessage).await()

        // Update last message on chat
        firestore.collection("chats").document(chatId).update(
            mapOf(
                "lastMessageText" to message.content,
                "lastMessageTime" to message.timestamp
            )
        ).await()
    }

    suspend fun deleteMessageForEveryone(chatId: String, messageId: String) {
        firestore.collection("chats").document(chatId)
            .collection("messages").document(messageId)
            .update("isDeletedForEveryone", true).await()
    }

    suspend fun deleteMessageForUser(chatId: String, messageId: String, userId: String) {
        val docRef = firestore.collection("chats").document(chatId).collection("messages").document(messageId)
        val snapshot = docRef.get().await()
        val msg = snapshot.toObject(Message::class.java) ?: return
        val currentDeleted = msg.deletedFor.toMutableList()
        if (!currentDeleted.contains(userId)) {
            currentDeleted.add(userId)
            docRef.update("deletedFor", currentDeleted).await()
        }
    }

    suspend fun uploadMedia(inputStream: InputStream, filename: String): String {
        val storageRef = storage.reference.child("chat_media/${UUID.randomUUID()}_$filename")
        storageRef.putStream(inputStream).await()
        return storageRef.downloadUrl.await().toString()
    }
}
