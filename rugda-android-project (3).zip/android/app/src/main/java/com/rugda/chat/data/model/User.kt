package com.rugda.chat.data.model

data class User(
    val id: String = "",
    val name: String = "",
    val username: String = "",
    val phone: String = "",
    val avatar: String = "",
    val isOnline: Boolean = false,
    val lastSeen: Long = System.currentTimeMillis(),
    val hideOnlineStatus: Boolean = false,
    val readReceiptsEnabled: Boolean = true,
    val bio: String = "Hey there! I am using RUGDA."
)
