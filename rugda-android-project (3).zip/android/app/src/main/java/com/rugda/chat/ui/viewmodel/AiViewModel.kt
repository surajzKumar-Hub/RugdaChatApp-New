package com.rugda.chat.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rugda.chat.data.model.Message
import com.rugda.chat.data.model.MessageType
import com.rugda.chat.data.repository.GeminiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AiViewModel(
    private val geminiRepository: GeminiRepository
) : ViewModel() {

    private val _aiMessages = MutableStateFlow<List<Message>>(emptyList())
    val aiMessages: StateFlow<List<Message>> = _aiMessages

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun sendAiPrompt(prompt: String, useProModel: Boolean = false) {
        if (prompt.isBlank()) return
        val userMsg = Message(
            id = System.currentTimeMillis().toString(),
            senderId = "me",
            senderName = "You",
            content = prompt,
            type = MessageType.TEXT
        )
        _aiMessages.value = _aiMessages.value + userMsg

        _isLoading.value = true
        viewModelScope.launch {
            val reply = geminiRepository.getAiReply(prompt, useProModel)
            val aiMsg = Message(
                id = (System.currentTimeMillis() + 1).toString(),
                senderId = "rugda_ai",
                senderName = "RUGDA AI",
                content = reply,
                type = MessageType.TEXT
            )
            _aiMessages.value = _aiMessages.value + aiMsg
            _isLoading.value = false
        }
    }
}
