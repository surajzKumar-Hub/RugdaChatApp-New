package com.rugda.chat.data.model

enum class CallType {
    VOICE, VIDEO
}

enum class CallStatus {
    IDLE, DIALING, RINGING, CONNECTED, ENDED
}

data class CallState(
    val callId: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerAvatar: String = "",
    val receiverId: String = "",
    val callType: CallType = CallType.VIDEO,
    val status: CallStatus = CallStatus.IDLE,
    val isMuted: Boolean = false,
    val isCameraOff: Boolean = false,
    val isSpeakerOn: Boolean = true
)
