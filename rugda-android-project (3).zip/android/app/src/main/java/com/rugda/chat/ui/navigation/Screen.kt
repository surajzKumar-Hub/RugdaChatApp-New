package com.rugda.chat.ui.navigation

sealed class Screen(val route: String) {
    object Auth : Screen("auth")
    object ChatList : Screen("chat_list")
    object ChatDetail : Screen("chat_detail/{chatId}/{chatName}") {
        fun createRoute(chatId: String, chatName: String) = "chat_detail/$chatId/$chatName"
    }
    object AiAssistant : Screen("ai_assistant")
    object Call : Screen("call")
    object Settings : Screen("settings")
}
