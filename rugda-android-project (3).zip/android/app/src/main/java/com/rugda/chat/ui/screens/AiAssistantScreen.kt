package com.rugda.chat.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rugda.chat.data.model.Message
import com.rugda.chat.ui.theme.SenderBubbleGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    onBack: () -> Unit
) {
    var promptInput by remember { mutableStateOf("") }
    val aiMessages = remember {
        mutableStateListOf(
            Message(
                id = "0",
                senderId = "rugda_ai",
                senderName = "RUGDA AI",
                content = "Hello! I am RUGDA AI powered by Gemini 1.5. How can I help you write code, summarize text, or translate messages today?",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF4FC3F7))
                        Text("RUGDA AI Assistant", fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        placeholder = { Text("Ask RUGDA AI anything...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    IconButton(
                        onClick = {
                            if (promptInput.isNotBlank()) {
                                aiMessages.add(
                                    Message(
                                        id = System.currentTimeMillis().toString(),
                                        senderId = "me",
                                        senderName = "You",
                                        content = promptInput
                                    )
                                )
                                val userPrompt = promptInput
                                promptInput = ""

                                // Simulated async reply
                                aiMessages.add(
                                    Message(
                                        id = (System.currentTimeMillis() + 1).toString(),
                                        senderId = "rugda_ai",
                                        senderName = "RUGDA AI",
                                        content = "I have processed your query: '$userPrompt'. Your RUGDA Android application is ready with real-time Firestore, WebRTC, and Gemini integration!"
                                    )
                                )
                            }
                        },
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .background(Color(0xFF0284C7), CircleShape)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(aiMessages) { msg ->
                val isMe = msg.senderId == "me"
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Surface(
                        color = if (isMe) SenderBubbleGreen else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Text(
                            text = msg.content,
                            color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(12.dp),
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
