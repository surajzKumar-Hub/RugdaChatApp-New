package com.rugda.chat.data.model

enum class MessageType {
    TEXT, IMAGE, VIDEO, VOICE, DOCUMENT, AI_PROMPT
}

enum class MessageStatus {
    SENDING, SENT, DELIVERED, READ
}

data class Message(
    val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val type: MessageType = MessageType.TEXT,
    val status: MessageStatus = MessageStatus.SENT,
    val mediaUrl: String? = null,
    val mediaDurationSeconds: Int? = null,
    val isEncrypted: Boolean = true,
    val translatedContent: String? = null,
    val reactions: Map<String, String> = emptyMap(), // userId -> emoji
    val deletedFor: List<String> = emptyList(), // userIds
    val isDeletedForEveryone: Boolean = false
)
