package com.rugda.chat.data.model

enum class ChatType {
    DIRECT, GROUP, CHANNEL, AI_BOT
}

data class Chat(
    val id: String = "",
    val name: String = "",
    val type: ChatType = ChatType.DIRECT,
    val avatar: String = "",
    val participants: List<String> = emptyList(), // user IDs
    val unreadCounts: Map<String, Int> = emptyMap(), // userId -> count
    val lastMessageText: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val isVerified: Boolean = false,
    val typingUsers: List<String> = emptyList(),
    val pinnedMessages: List<String> = emptyList()
)
