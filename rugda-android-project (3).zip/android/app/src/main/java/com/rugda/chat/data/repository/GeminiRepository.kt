package com.rugda.chat.data.repository

import com.rugda.chat.data.remote.GeminiApiService

class GeminiRepository(private val geminiApiService: GeminiApiService) {

    suspend fun getAiReply(prompt: String, useProModel: Boolean = false): String {
        return geminiApiService.generateAiReply(prompt, useProModel)
    }

    suspend fun translateMessage(content: String, targetLanguage: String): String {
        return geminiApiService.translateText(content, targetLanguage)
    }

    suspend fun summarizeChat(messages: List<String>): String {
        return geminiApiService.summarizeChatHistory(messages)
    }
}
