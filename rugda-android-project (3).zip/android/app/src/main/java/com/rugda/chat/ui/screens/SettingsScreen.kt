package com.rugda.chat.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {
    var darkMode by remember { mutableStateOf(false) }
    var hideOnlineStatus by remember { mutableStateOf(false) }
    var readReceipts by remember { mutableStateOf(true) }
    var messageSounds by remember { mutableStateOf(true) }
    var biometricLock by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("RUGDA Preferences", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Appearance & Theme", fontWeight = FontWeight.Bold, color = Color(0xFF0284C7), fontSize = 14.sp)
                Card(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Dark Theme (Pure Black)", fontWeight = FontWeight.SemiBold)
                            Text("Switch to OLED black theme", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = darkMode, onCheckedChange = { darkMode = it })
                    }
                }
            }

            item {
                Text("Privacy & Security", fontWeight = FontWeight.Bold, color = Color(0xFF0284C7), fontSize = 14.sp)
                Card(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Hide Online Status", fontWeight = FontWeight.SemiBold)
                            Switch(checked = hideOnlineStatus, onCheckedChange = { hideOnlineStatus = it })
                        }
                        Divider()
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Read Receipts (Checkmarks)", fontWeight = FontWeight.SemiBold)
                            Switch(checked = readReceipts, onCheckedChange = { readReceipts = it })
                        }
                        Divider()
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Biometric Fingerprint Lock", fontWeight = FontWeight.SemiBold)
                            Switch(checked = biometricLock, onCheckedChange = { biometricLock = it })
                        }
                    }
                }
            }

            item {
                Text("Alerts & Storage", fontWeight = FontWeight.Bold, color = Color(0xFF0284C7), fontSize = 14.sp)
                Card(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Notification Sounds", fontWeight = FontWeight.SemiBold)
                            Switch(checked = messageSounds, onCheckedChange = { messageSounds = it })
                        }
                        Divider()
                        Button(
                            onClick = { /* Clear Cache */ },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.15f), contentColor = Color.Red),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Clear Media Cache (14.2 MB)")
                        }
                    }
                }
            }
        }
    }
}
