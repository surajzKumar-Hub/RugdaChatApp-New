package com.rugda.chat.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rugda.chat.data.model.Chat
import com.rugda.chat.data.model.Message
import com.rugda.chat.data.model.MessageType
import com.rugda.chat.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.InputStream

class ChatViewModel(
    private val chatRepository: ChatRepository = ChatRepository()
) : ViewModel() {

    private val _chats = MutableStateFlow<List<Chat>>(emptyList())
    val chats: StateFlow<List<Chat>> = _chats

    private val _currentMessages = MutableStateFlow<List<Message>>(emptyList())
    val currentMessages: StateFlow<List<Message>> = _currentMessages

    fun loadUserChats(userId: String) {
        viewModelScope.launch {
            chatRepository.getChatsForUser(userId).collect { list ->
                _chats.value = list
            }
        }
    }

    fun loadChatMessages(chatId: String) {
        viewModelScope.launch {
            chatRepository.getMessagesForChat(chatId).collect { list ->
                _currentMessages.value = list
            }
        }
    }

    fun sendTextMessage(chatId: String, senderId: String, senderName: String, text: String) {
        viewModelScope.launch {
            val message = Message(
                chatId = chatId,
                senderId = senderId,
                senderName = senderName,
                content = text,
                type = MessageType.TEXT
            )
            chatRepository.sendMessage(chatId, message)
        }
    }

    fun uploadAndSendMedia(
        chatId: String,
        senderId: String,
        senderName: String,
        inputStream: InputStream,
        fileName: String,
        type: MessageType
    ) {
        viewModelScope.launch {
            val mediaUrl = chatRepository.uploadMedia(inputStream, fileName)
            val message = Message(
                chatId = chatId,
                senderId = senderId,
                senderName = senderName,
                content = if (type == MessageType.IMAGE) "📷 Photo" else "📁 Attachment",
                type = type,
                mediaUrl = mediaUrl
            )
            chatRepository.sendMessage(chatId, message)
        }
    }

    fun deleteMessageForEveryone(chatId: String, messageId: String) {
        viewModelScope.launch {
            chatRepository.deleteMessageForEveryone(chatId, messageId)
        }
    }

    fun deleteMessageForMe(chatId: String, messageId: String, userId: String) {
        viewModelScope.launch {
            chatRepository.deleteMessageForUser(chatId, messageId, userId)
        }
    }
}
