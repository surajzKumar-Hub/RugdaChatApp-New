package com.rugda.chat.ui.theme

import androidx.compose.ui.graphics.Color

val PrimarySky = Color(0xFF0284C7)
val PrimaryCyan = Color(0xFF4FC3F7)
val SenderBubbleGreen = Color(0xFF6FCF97) // Soft Emerald Green
val EmeraldAccent = Color(0xFF22C55E)

val LightBackground = Color(0xFFFFFFFF)
val DarkBackground = Color(0xFF000000)

val LightSurface = Color(0xFFF8FAFC)
val DarkSurface = Color(0xFF121212)

val ReceiverBubbleLight = Color(0xFFFFFFFF)
val ReceiverBubbleDark = Color(0xFF1E1E1E)

val TextPrimaryLight = Color(0xFF0F172A)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryLight = Color(0xFF64748B)
val TextSecondaryDark = Color(0xFFA1A1AA)
