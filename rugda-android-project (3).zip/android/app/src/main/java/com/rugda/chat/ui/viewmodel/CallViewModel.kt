package com.rugda.chat.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.rugda.chat.data.model.CallState
import com.rugda.chat.data.model.CallStatus
import com.rugda.chat.data.model.CallType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CallViewModel : ViewModel() {

    private val _callState = MutableStateFlow(CallState())
    val callState: StateFlow<CallState> = _callState

    fun startOutgoingCall(
        receiverId: String,
        receiverName: String,
        receiverAvatar: String,
        callType: CallType
    ) {
        _callState.value = CallState(
            callId = System.currentTimeMillis().toString(),
            callerName = receiverName,
            callerAvatar = receiverAvatar,
            receiverId = receiverId,
            callType = callType,
            status = CallStatus.DIALING
        )
    }

    fun answerIncomingCall() {
        _callState.value = _callState.value.copy(status = CallStatus.CONNECTED)
    }

    fun toggleMute() {
        _callState.value = _callState.value.copy(isMuted = !_callState.value.isMuted)
    }

    fun toggleCamera() {
        _callState.value = _callState.value.copy(isCameraOff = !_callState.value.isCameraOff)
    }

    fun toggleSpeaker() {
        _callState.value = _callState.value.copy(isSpeakerOn = !_callState.value.isSpeakerOn)
    }

    fun endCall() {
        _callState.value = _callState.value.copy(status = CallStatus.ENDED)
        _callState.value = CallState() // Reset
    }
}
